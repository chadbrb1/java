package fr.epsi.b3.recensement;

import java.io.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class test {
    public static void main(String[] args) throws FileNotFoundException {
    	 ArrayList<Recensement>R = new ArrayList<Recensement>();
         ArrayList <Region> tabRegion = new ArrayList<Region>() ; // cette liste contiendra toutes les regions du document
         ArrayList <String> tabNomRegion = new ArrayList<String>() ; // cette liste contiendra les noms de toutes les regions du document
         
         ArrayList <String> tabNomDepartement = new ArrayList<String>() ; // cette liste contiendra toutes les regions du document
         ArrayList<Departement> tabDepartment = new ArrayList<Departement>();
         
         ArrayList<Ville> tabVille = new ArrayList<Ville>();
         ArrayList<String>tabNomVille = new ArrayList<String>();
        
    	try
        {
          // Le fichier d'entrée
          FileInputStream file = new FileInputStream("src/fr/epsi/b3/recensement/recensement_2016.csv");   
          Scanner scanner = new Scanner(file);  
          PrintWriter writer = new PrintWriter("text.txt", "UTF-8");
         

         
         
          
          while(scanner.hasNextLine() )
          {
        	  String s = scanner.nextLine();
      
           int longg = s.length();
          ArrayList<Integer>virgule = new ArrayList<Integer>();
          
         
          
          
            for (int x = 0; x < longg; x ++)
            {
            	if (s.charAt(x) == ';')
            	{
            		virgule.add(x);        	
            	}
            }
            String Numregion = s.substring(0,virgule.get(0));
           String region = s.substring(virgule.get(0)+1,virgule.get(1));
           String departement = s.substring(virgule.get(1)+1,virgule.get(2));
           String arrondissement = s.substring(virgule.get(2)+1,virgule.get(3));
           String canton = s.substring(virgule.get(3)+1,virgule.get(4));
           String commune = s.substring(virgule.get(4)+1,virgule.get(5));
           String NomCommune = s.substring(virgule.get(5)+1,virgule.get(6));
           String PopulationMun = s.substring(virgule.get(6)+1,virgule.get(7));
           String PopulationComptee = s.substring(virgule.get(7)+1,virgule.get(8));
           String PopulationTotale = s.substring(virgule.get(8)+1,longg);
           
           if (existName(region,tabNomRegion) == false )
           {
        	   tabNomRegion.add(region);
        	   Region r = new Region (Numregion, region);
        	   tabRegion.add(r);
           }
           Departement d = new Departement (departement);;
           Ville v = new Ville(NomCommune,PopulationTotale, departement,region);
           tabVille.add(v);
           
           
           if (existName(departement,tabNomDepartement) == false )
           {
        	   tabNomDepartement.add(departement);
        	   tabDepartment.add(d);
        	  
           }
          
           
         
           
           
         
          /*
            else 
           
           {
        	   int populationPrecedente = tabRegion.get(returnIndexListe(region,tabNomRegion)).getPopulationRegion();
        	   tabRegion.get(returnIndexListe(region,tabNomRegion)).setPopulationRegion(populationPrecedente+Integer.parseInt(PopulationTotale));
           }
        */ 
           
           Recensement r1 = new Recensement (Numregion, region, departement, arrondissement, 
        		   canton, commune, NomCommune, PopulationMun, PopulationComptee, PopulationTotale);
           
           
           
    
         
        		   
        		  
        	  
           
            R.add(r1);
           /* System.out.println(Numregion);
            System.out.println(region);
            System.out.println(departement);
            System.out.println(arrondissement);
            System.out.println(canton);
            System.out.println(commune);
            System.out.println(NomCommune);
            System.out.println(PopulationMun);
            System.out.println(PopulationComptee);
            System.out.println(PopulationTotale);
            */
           
          }
          scanner.close();    
        }
        catch(IOException e)
        {
          e.printStackTrace();
        }
        
    	
    	
    	
    	
    	
    	
    	for (int i = 0 ; i < tabRegion.size(); i ++)
    	{
    		tabRegion.get(i).setPopulationRegion(rechPopRegion(tabRegion.get(i).getCodeRegion(), R));
    		//on initaile la population totale de chaque région
    	}
    	
    	
    	for (int i = 0 ; i < tabDepartment.size(); i ++)
    	{
    		tabDepartment.get(i).setPopulation(rechPopDepartement(tabDepartment.get(i).getNumDepartement(), R));
    		//on initaile la population totale de chaque departement
    	}
    	
    	
    	
    	System.out.println(rechPopVille("Paris" , R));
    	System.out.println(rechPopDepartement("1" , R));
    	
    	System.out.println(rechPopRegion("84" , R));
    	System.out.println(regionPlus(R));
    	
    	
    	
    	/*
    	for (int i = 0 ; i < tabRegion.size(); i ++)
    	{
    		System.out.println(tabRegion.get(i).getNomRegion());
    		System.out.println(tabRegion.get(i).getPopulationRegion());
    	}
    	
    	System.out.println();
    	System.out.println();
    	*/
    	
    	
    
    	
    	// 10 région les plus peuplées
    	/*
    	ArrayList<Region> newR = tri(tabRegion) ;
    	
    	
    	for (int i = 0 ; i < newR.size(); i ++)
    	{
    		System.out.println(newR.get(i).getNomRegion());
    		System.out.println(newR.get(i).getPopulationRegion());
    	}
    	*/
    	/*
    	
    	int [] t = tri1();
    	for (int i = 0 ; i < t.length; i++)
    	{
    		System.out.println(t[i]);
    	}
 		*/
 		
    	/*
    	for (int i = 0 ; i < tabDepartment.size(); i ++)
    	{
    		System.out.println(tabDepartment.get(i).getNumDepartement());
    		System.out.println(tabDepartment.get(i).getPopulation());
    	}
    	*/
    	
    	/*
    	ArrayList<Departement> newD = triDepartement(tabDepartment) ;
    	for (int i = 0 ; i < newD.size(); i ++)
    	{
    		System.out.println(newD.get(i).getNumDepartement());
    		System.out.println(newD.get(i).getPopulation());
    	}
    	
    	*/
    
    	//afficheVilleDepartement("1",tabDepartment);
    	
    	ajoutVilleDepartement(tabVille,tabDepartment);
    	ajoutVilleRegion(tabVille,tabRegion);
    	
    	
    	/*
 		System.out.println(tabDepartment.size());
 		
 		for (int i = 0; i < tabDepartment.size(); i ++)
 		{
 			Departement d = tabDepartment.get(i);
 			System.out.println(tabDepartment.get(i).getNumDepartement());
 			System.out.println(d.getListeVille().size());
 		
 		}
 		
 		
 		
 		int x = 0;
 		
 		String dep = "1";
 		Departement d = rechDepartement(dep, tabDepartment);
 		 ArrayList<Ville> newD = triVille(d.getListeVille()) ;
 		for (int i = 0;i <newD.size(); i ++)
 		{
 			System.out.println(newD.get(i).getNomVille());
 			//System.out.println(d.getListeVille().get(i).getNomVille());
 		}
 		
 		*/
 		
 		/*
 		String reg = "Hauts-de-France";
 		Region r = rechRegion(reg, tabRegion);
 		System.out.println(r.getNomRegion());
 		 ArrayList<Ville> newV = triVille(r.getListeVille()) ;
 		 System.out.println(newV.size());
 		for (int i = 0;i <newV.size(); i ++)
 		{
 			System.out.println(newV.get(i).getNomVille());
 			//System.out.println(d.getListeVille().get(i).getNomVille());
 		}
 		
 		*/
    	
    	/*
        ArrayList<Ville> newD = triVille(tabVille) ;
    	
    	System.out.println(tabVille.size());
    	
    	for (int i = 0 ; i < newD.size(); i ++)
    	{
    		Q>a	
    	}
 		
*/
 		
 		System.out.println();
 		System.out.println();
 		System.out.println();
 		
 		ArrayList<Ville> testVille = testTriVille(tabVille);
 		for (Ville v : testVille)
 		{
 			System.out.println(v.getNomVille());
 		}
    }
    
    
    public static ArrayList<Ville> testTriVille(ArrayList<Ville> v)
    {
    	Collections.sort(v);
    	
    	ArrayList<Ville> listeFinale = new ArrayList<Ville>() ;
    	for (int i = 0 ; i < 10; i ++) 
    	{
    		listeFinale.add(v.get(i));
    	}
    	
    	return listeFinale ;
    }
    
    public static String rechPopVille(String ville, ArrayList<Recensement> r) {
    
    	String population = "";
    	for (int i = 0 ; i < r.size(); i ++)
    	{
    		Recensement r1 = r.get(i);
    		if (r1.getNomCommune().equals(ville)) 
    		{
    			population = r1.getPopulationTotale();
    			
    		}
    	}
    	
    	if (population.length() > 0)
    	{
    		return population;
    	}
    	else 
    	{
    		return "La ville entrée est erronée ";
    	}
    }
    
    
    public static void ajoutVilleDepartement(ArrayList<Ville> v, ArrayList<Departement> de)
    {
    		
    	for (int i = 0; i < v.size(); i ++)
    	{
    		String departementVille = v.get(i).getDepartement();
    		for (int j =0; j < de.size(); j++)
    		{
    			String nomDepartement = de.get(j).getNumDepartement();
    			if (nomDepartement.equals(departementVille))
    			{
    				de.get(j).ajoutVille(v.get(i));
    			}

    		}
    	}
    	
    }
    
    public static void ajoutVilleRegion(ArrayList<Ville> v, ArrayList<Region> re)
    {
    		
    	for (int i = 0; i < v.size(); i ++)
    	{
    		String RegionVille = v.get(i).getRegion();
    		for (int j =0; j < re.size(); j++)
    		{
    			String NomRegion = re.get(j).getNomRegion();
    			if (NomRegion.equals(RegionVille))
    			{
    				re.get(j).ajoutVille(v.get(i));
    			}

    		}
    	}
    	
    }
    
    public static String rechPopDepartement(String depart, ArrayList<Recensement> r)
    {
    	String dep = "";
    	int total = 0;
    	int verif = -1;
    	for (int i = 0 ; i < r.size(); i ++)
    	{
    		Recensement r1 = r.get(i);
    		if (r1.getCodeDepartement().equals(depart)) 
    		{
    			verif ++;
    			total = total + Integer.parseInt(r1.getPopulationTotale());
    		}
    	}
    	
    	if (verif >= 0)
    	{
    		return dep+total;
    	}
    	else 
    	{
    		return "Departement eronne";
    	}
    	
    }
    
    
    
    public static void afficheVilleDepartement(String d, ArrayList<Departement>nomD)
    {
    	for (int i = 0 ; i < nomD.size(); i++)
    	{
    		if (nomD.get(i).getNumDepartement().equals(nomD))
    		{
    			System.out.println(nomD.get(i).getPopulation());
    			ArrayList<Ville> v = nomD.get(i).getListeVille();
    			for (int j = 0 ; j < v.size(); j ++)
    			{
    				System.out.println(v.get(j).getNomVille());
    			}
    		}
    	}
    }
    
    
    
    public static ArrayList<Region> tri (ArrayList<Region> liste)
    {
    	ArrayList<Region> listeTriee = liste ;
    	ArrayList<String> listeNomRegion = new ArrayList<String>() ;
    	
    	for (int i = 0; i < liste.size(); i++)
    	{
    		
    		for (int j = 0 ; j<liste.size() ; j++)
    		{
    			
    			if (Integer.parseInt(listeTriee.get(i).getPopulationRegion()) >  Integer.parseInt(listeTriee.get(j).getPopulationRegion())) 
    			{
					Region temp = listeTriee.get(i);
					listeTriee.set(i, listeTriee.get(j));
					listeTriee.set(j, temp);
				}
    			
    		}	
    	}
    	
    	ArrayList<Region> listeFinale = new ArrayList<Region>() ;
    	for (int i = 0 ; i < 10; i ++) 
    	{
    		listeFinale.add(listeTriee.get(i));
    	}
    	
    	return listeFinale ;
    	
    }
    
    public static Departement rechDepartement(String d, ArrayList<Departement> de)
    {
    	for (int i = 0; i <de.size(); i ++)
    	{
    		if (de.get(i).getNumDepartement().equals(d))
    		{
    			return de.get(i);
    		}
    	}
    	
    	return null;
    }
    
    public static Region rechRegion(String d, ArrayList<Region> r)
    {
    	for (int i = 0; i <r.size(); i ++)
    	{
    		if (r.get(i).getNomRegion().equals(d))
    		{
    			return r.get(i);
    		}
    	}
    	
    	return null;
    }
    
    public static ArrayList<Departement> triDepartement (ArrayList<Departement> liste)
    {
    	ArrayList<Departement> listeTriee = liste ;
    	ArrayList<String> listeNomRegion = new ArrayList<String>() ;
    	
    	for (int i = 0; i < liste.size(); i++)
    	{
    		
    		for (int j = 0 ; j<liste.size() ; j++)
    		{
    			
    			if (Integer.parseInt(listeTriee.get(i).getPopulation()) >  Integer.parseInt(listeTriee.get(j).getPopulation())) 
    			{
					Departement temp = listeTriee.get(i);
					listeTriee.set(i, listeTriee.get(j));
					listeTriee.set(j, temp);
				}
    			
    		}	
    	}
    	
    	ArrayList<Departement> listeFinale = new ArrayList<Departement>() ;
    	for (int i = 0 ; i < 10; i ++) 
    	{
    		listeFinale.add(listeTriee.get(i));
    	}
    	
    	return listeFinale ;
    	
    }
    
    
    public static ArrayList<Ville> triVille (ArrayList<Ville> liste)
    {
    	ArrayList<Ville> listeTriee = liste ;

    	
    	for (int i = 0; i < liste.size(); i++)
    	{
    		
    		for (int j = 0 ; j<liste.size() ; j++)
    		{
    			
    			if (Integer.parseInt(listeTriee.get(i).getPopulationVille()) >  Integer.parseInt(listeTriee.get(j).getPopulationVille())) 
    			{
					Ville temp = listeTriee.get(i);
					listeTriee.set(i, listeTriee.get(j));
					listeTriee.set(j, temp);
				}
    			
    		}	
    	}
    	
    	ArrayList<Ville> listeFinale = new ArrayList<Ville>() ;
    	for (int i = 0 ; i < 10; i ++) 
    	{
    		listeFinale.add(listeTriee.get(i));
    	}
    	
    	return listeFinale ;
    	
    }
    public static int [] tri1 ()
    {
    	int [] t = {1,7,0,4,6};
    	
    	
    	
    	
    	for (int i = 0; i < t.length; i++) {
			for (int j = 0; j < t.length; j++) {
				if (t[i] > t[j]) {
					int temp = t[i];
					t[i] = t[j];
					t[j] = temp;
				}
			}
		}
    	return t;
    }
    
    public static String rechPopRegion(String region, ArrayList<Recensement> r)
    {
    	String dep = "";
    	int total = 0;
    	int verif = -1;
    	for (int i = 0 ; i < r.size(); i ++)
    	{
    		Recensement r1 = r.get(i);
    		if (r1.getCodeRegion().equals(region) || r1.getNomCommune().equals(region)) 
    		{
    			verif ++;
    			total = total + Integer.parseInt(r1.getPopulationTotale());
    		}
    	}
    	
    	if (verif >= 0)
    	{
    		return dep+total;
    	}
    	else 
    	{
    		return "region eronne";
    	}
    	
    }
    
    
    public static String regionPlus(ArrayList<Recensement> r)
    {
    	String dep = "";
    	int total = 0;
    	int verif = -1;
    	
    	ArrayList<String> reg = new ArrayList<String>();
    	
    	
    	for (int i = 0 ; i < r.size(); i ++)
    	{
    		
    		Recensement r1 = r.get(i);
    		String region = r1.getNomRegion();
    		if (!existName(region,reg)) 
    		{
    			reg.add(r1.getNomRegion());
                verif++;
    		}
    		
    	}
    	
    	if (verif >= 0)
    	{
    		return dep+reg.size();
    	}
    	else 
    	{
    		return "a eronne";
    	}
    	
    }
    
    
    // permet de savoir une chaine de caractere existe déja dans une liste !
    public static Boolean existName(String s, ArrayList<String> a )
    {
    	int occur = 0;
    	for (int i = 0; i < a.size() ; i ++)
    	{
    		if (s.equals(a.get(i)))
    		{
    			occur++;
    		}
    	}
    	
    	if (occur > 0)
    	{
    		return true;
    	}
    	else 
    	{
    		return false ;
    	}
    }

    
    
 // retourne l'index d'une chaine de caractere presente dans une liste 
    public static int returnIndexListe(String s, ArrayList<String> a )
    {
    	int occur = 0;
    	for (int i = 0; i < a.size() ; i ++)
    	{
    		if (s.equals(a.get(i)))
    		{
    			return i;
    		}
    	}
    	
    	return -1;
    }

}