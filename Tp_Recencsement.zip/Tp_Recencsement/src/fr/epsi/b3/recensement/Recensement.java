package fr.epsi.b3.recensement;

public class Recensement {
	private String codeRegion;
	private String nomRegion;
	private String codeDepartement;
	private String codeArrondissement;
	private String codeCanton;
	private String codeCommune;
	private String NomCommune;
	private String populationMunicipale;
	private String population_A_Part;
	private String populationTotale;
	
	public Recensement(String codeRegion, String nomRegion, String codeDepartement, String codeArrondissement, String codeCanton,
			String codeCommune, String nomCommune, String populationMunicipale, String population_A_Part, String populationTotale) {
		super();
		this.codeRegion = codeRegion;
		this.nomRegion = nomRegion;
		this.codeDepartement = codeDepartement;
		this.codeArrondissement = codeArrondissement;
		this.codeCanton = codeCanton;
		this.codeCommune = codeCommune;
		NomCommune = nomCommune;
		this.populationMunicipale = populationMunicipale;
		this.population_A_Part = population_A_Part;
		this.populationTotale = populationTotale;
	}
	public String getCodeRegion() {
		return codeRegion;
	}
	public void setCodeRegion(String codeRegion) {
		this.codeRegion = codeRegion;
	}
	public String getNomRegion() {
		return nomRegion;
	}
	public void setNomRegion(String nomRegion) {
		this.nomRegion = nomRegion;
	}
	public String getCodeDepartement() {
		return codeDepartement;
	}
	public void setCodeDepartement(String codeDepartement) {
		this.codeDepartement = codeDepartement;
	}
	public String getCodeArrondissement() {
		return codeArrondissement;
	}
	public void setCodeArrondissement(String codeArrondissement) {
		this.codeArrondissement = codeArrondissement;
	}
	public String getCodeCanton() {
		return codeCanton;
	}
	public void setCodeCanton(String codeCanton) {
		this.codeCanton = codeCanton;
	}
	public String getCodeCommune() {
		return codeCommune;
	}
	public void setCodeCommune(String codeCommune) {
		this.codeCommune = codeCommune;
	}
	public String getNomCommune() {
		return NomCommune;
	}
	public void setNomCommune(String nomCommune) {
		NomCommune = nomCommune;
	}
	public String getPopulationMunicipale() {
		return populationMunicipale;
	}
	public void setPopulationMunicipale(String populationMunicipale) {
		this.populationMunicipale = populationMunicipale;
	}
	public String getPopulation_A_Part() {
		return population_A_Part;
	}
	public void setPopulation_A_Part(String population_A_Part) {
		this.population_A_Part = population_A_Part;
	}
	public String getPopulationTotale() {
		return populationTotale;
	}
	public void setPopulationTotale(String populationTotale) {
		this.populationTotale = populationTotale;
	}
	
	
	

}
