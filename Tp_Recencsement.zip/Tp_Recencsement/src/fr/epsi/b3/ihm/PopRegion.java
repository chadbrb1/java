package fr.epsi.b3.ihm;
import fr.epsi.b3.recensement.*;
import java.awt.BorderLayout;


import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Window.Type;
import java.awt.event.ActionEvent;
import java.awt.Dialog.ModalExclusionType;
import javax.swing.JTextField;
import javax.swing.ListModel;
import javax.swing.SwingConstants;
import javax.swing.DefaultListModel;
import javax.swing.DropMode;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JSplitPane;
import javax.swing.JTextArea;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.ArrayList;
import java.util.Vector;

import javax.swing.ImageIcon;
import java.awt.Color;
import javax.swing.UIManager;
import java.awt.SystemColor;
import javax.swing.JList;
import javax.swing.JTextPane;
import javax.swing.JComboBox;

public class PopRegion extends JFrame implements ActionListener, ItemListener{

	private JPanel contentPane;
	private JButton buttonQuitter;
	private JLabel lblNewLabel;
	private JButton btnAccueil;


	/**
	 * Create the frame.
	 */
	public PopRegion() {
		
		setAlwaysOnTop(true);
		setTitle("Tp Recensement");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(0,50, 776, 435);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		
		buttonQuitter = new JButton("Quitter");
		buttonQuitter.setFont(new Font("Arial Unicode MS", Font.BOLD | Font.ITALIC, 19));
		buttonQuitter.setBackground(Color.WHITE);
		buttonQuitter.setForeground(Color.BLACK);
		buttonQuitter.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (e.getSource() == buttonQuitter)
				{
					System.exit(0);
					
				}
			}
		});

		buttonQuitter.setBounds(591, 338, 155, 44);
		contentPane.add(buttonQuitter);
		
		lblNewLabel = new JLabel("Recencement");
		lblNewLabel.setForeground(Color.BLACK);
		lblNewLabel.setBackground(Color.WHITE);
		lblNewLabel.setFont(new Font("Arial Unicode MS", Font.BOLD | Font.ITALIC, 19));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(17, 6, 717, 53);
		contentPane.add(lblNewLabel);
		
		
		ArrayList<Ville>ville = Application.triVille();
		
		
		
		
		
		
		JButton btnCartes_1 = new JButton("Départements");
		btnCartes_1.setForeground(Color.BLACK);
		btnCartes_1.setFont(new Font("Arial Unicode MS", Font.BOLD | Font.ITALIC, 19));
		btnCartes_1.setBackground(Color.WHITE);
		btnCartes_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent a) {
				PopDepartement frame = new PopDepartement();
				frame.setVisible(true);
				PopRegion.this.dispose();
			}
		});
		btnCartes_1.setBounds(424, 338, 155, 44);
		contentPane.add(btnCartes_1);
		
		JButton btnCartes_1_1 = new JButton("Population");
		btnCartes_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Population frame = new Population();
				frame.setVisible(true);
				PopRegion.this.dispose();
			}
		});
		btnCartes_1_1.setForeground(Color.BLACK);
		btnCartes_1_1.setFont(new Font("Arial Unicode MS", Font.BOLD | Font.ITALIC, 19));
		btnCartes_1_1.setBackground(Color.WHITE);
		btnCartes_1_1.setBounds(196, 338, 155, 44);
		contentPane.add(btnCartes_1_1);
		
		btnAccueil = new JButton("Accueil");
		btnAccueil.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Accueil frame = new Accueil();
				frame.setVisible(true);
				PopRegion.this.dispose();
			}
		});
		btnAccueil.setForeground(Color.BLACK);
		btnAccueil.setFont(new Font("Arial Unicode MS", Font.BOLD | Font.ITALIC, 19));
		btnAccueil.setBackground(Color.WHITE);
		btnAccueil.setBounds(29, 338, 155, 44);
		contentPane.add(btnAccueil);
		
		
		DefaultListModel<String> model = new DefaultListModel<>();
		for ( int i = 0; i < ville.size(); i++ ){
			  model.addElement( ville.get(i).getNomVille() );
			}
		
		JTextPane txt1 = new JTextPane();
		txt1.setBounds(444, 92, 148, 29);
		contentPane.add(txt1);
		
		JLabel lblPopulationDuneRgion = new JLabel("Choisissez une région");
		lblPopulationDuneRgion.setHorizontalAlignment(SwingConstants.CENTER);
		lblPopulationDuneRgion.setForeground(Color.BLACK);
		lblPopulationDuneRgion.setFont(new Font("Arial Unicode MS", Font.ITALIC, 14));
		lblPopulationDuneRgion.setBackground(Color.WHITE);
		lblPopulationDuneRgion.setBounds(79, 134, 260, 44);
		contentPane.add(lblPopulationDuneRgion);
		

		JTextPane txt6 = new JTextPane();
		txt6.setBounds(622, 92, 148, 29);
		contentPane.add(txt6);
		
		JTextPane txt2 = new JTextPane();
		txt2.setBounds(444, 133, 148, 29);
		contentPane.add(txt2);
		
		JTextPane txt7 = new JTextPane();
		txt7.setBounds(622, 134, 148, 29);
		contentPane.add(txt7);
		
		JTextPane txt3 = new JTextPane();
		txt3.setBounds(444, 179, 148, 29);
		contentPane.add(txt3);
		
		JTextPane txt8 = new JTextPane();
		txt8.setBounds(622, 179, 148, 29);
		contentPane.add(txt8);
		
		JTextPane txt4 = new JTextPane();
		txt4.setBounds(444, 229, 148, 29);
		contentPane.add(txt4);
		
		JTextPane txt9 = new JTextPane();
		txt9.setBounds(622, 229, 148, 29);
		contentPane.add(txt9);
		
		JTextPane txt5 = new JTextPane();
		txt5.setBounds(444, 274, 148, 29);
		contentPane.add(txt5);
		
		JTextPane txt10 = new JTextPane();
		txt10.setBounds(622, 274, 148, 29);
		contentPane.add(txt10);
		
		JLabel lblNewLabel_1 = new JLabel("1");
		lblNewLabel_1.setBounds(417, 105, 15, 16);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("2");
		lblNewLabel_1_1.setBounds(417, 149, 15, 16);
		contentPane.add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_1_2 = new JLabel("3");
		lblNewLabel_1_2.setBounds(417, 197, 15, 16);
		contentPane.add(lblNewLabel_1_2);
		
		JLabel lblNewLabel_1_3 = new JLabel("4");
		lblNewLabel_1_3.setBounds(417, 244, 15, 16);
		contentPane.add(lblNewLabel_1_3);
		
		JLabel lblNewLabel_1_4 = new JLabel("5");
		lblNewLabel_1_4.setBounds(417, 285, 15, 16);
		contentPane.add(lblNewLabel_1_4);
		
		JLabel lblNewLabel_1_5 = new JLabel("10");
		lblNewLabel_1_5.setBounds(604, 285, 28, 16);
		contentPane.add(lblNewLabel_1_5);
		
		JLabel lblNewLabel_1_6 = new JLabel("9");
		lblNewLabel_1_6.setBounds(604, 244, 15, 16);
		contentPane.add(lblNewLabel_1_6);
		
		JLabel lblNewLabel_1_7 = new JLabel("8");
		lblNewLabel_1_7.setBounds(604, 197, 15, 16);
		contentPane.add(lblNewLabel_1_7);
		
		JLabel lblNewLabel_1_8 = new JLabel("7");
		lblNewLabel_1_8.setBounds(604, 149, 15, 16);
		contentPane.add(lblNewLabel_1_8);
		
		JLabel lblNewLabel_1_9 = new JLabel("6");
		lblNewLabel_1_9.setBounds(604, 105, 15, 16);
		contentPane.add(lblNewLabel_1_9);
		
		JComboBox comboBoxRegion = new JComboBox(vectorRegion());
		comboBoxRegion.setBounds(6, 179, 265, 27);
		contentPane.add(comboBoxRegion);
		ArrayList<Region> region = Application.returnListRegion();
		JButton btnRegion = new JButton("OK");
		btnRegion.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (e.getSource()==btnRegion)
				{
					
					
					Region r = Application.rechRegion(comboBoxRegion.getSelectedItem().toString());
			 		System.out.println(r.getNomRegion());
			 		 ArrayList<Ville> newV = Application.triVille(r.getListeVille()) ;
			 		 System.out.println(newV.size());
			 		
			 		txt1.setText(newV.get(0).getNomVille());
			 		txt2.setText(newV.get(1).getNomVille());
			 		txt3.setText(newV.get(2).getNomVille());
			 		txt4.setText(newV.get(3).getNomVille());
			 		txt5.setText(newV.get(4).getNomVille());
			 		txt6.setText(newV.get(5).getNomVille());
			 		txt7.setText(newV.get(6).getNomVille());
			 		txt8.setText(newV.get(7).getNomVille());
			 		txt9.setText(newV.get(8).getNomVille());
			 		txt10.setText(newV.get(9).getNomVille());
				}
			}
		});
		btnRegion.setForeground(Color.BLACK);
		btnRegion.setFont(new Font("Arial Unicode MS", Font.BOLD | Font.ITALIC, 12));
		btnRegion.setBackground(Color.WHITE);
		btnRegion.setBounds(283, 179, 68, 27);
		contentPane.add(btnRegion);
		
		
		
		JLabel lblVillesLes = new JLabel("10 villes les plus peuplées de cette région");
		lblVillesLes.setHorizontalAlignment(SwingConstants.CENTER);
		lblVillesLes.setForeground(Color.BLACK);
		lblVillesLes.setFont(new Font("Arial Unicode MS", Font.ITALIC, 14));
		lblVillesLes.setBackground(Color.WHITE);
		lblVillesLes.setBounds(434, 49, 286, 38);
		contentPane.add(lblVillesLes);
		

	}


	@Override
	public void itemStateChanged(ItemEvent e) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}
	
	
	public static Vector<String> vectorVille()
	{
		Vector<String> v = new Vector<String>();
		ArrayList<Ville> vi = Application.returnListVille();
		for (int i = 0 ; i < vi.size(); i++)
		{
			v.add(vi.get(i).getNomVille());
		}
		
		return v;
	}
	
	public static Vector<String> vectorRegion()
	{
		Vector<String> v = new Vector<String>();
		ArrayList<Region> vi = Application.returnListRegion();
		for (int i = 0 ; i < vi.size(); i++)
		{
			v.add(vi.get(i).getNomRegion());
		}
		
		return v;
	}
	
	public static Vector<String> vectorDepartement()
	{
		Vector<String> v = new Vector<String>();
		ArrayList<Departement> vi = Application.returnListDepartement();
		for (int i = 0 ; i < vi.size(); i++)
		{
			v.add(vi.get(i).getNumDepartement());
		}
		
		return v;
	}
}
